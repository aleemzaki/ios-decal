//
//  Stopwatch.swift
//  Stopwatch
//
//  Created by Aleem on 2/16/17.
//  Copyright © 2017 Aleem. All rights reserved.
//

import Foundation



func startTimer() {
    //date = Date()
    //ViewController.setup()
    //myTimer =
   // setup()
}



func stopTimer(){
    
   // myTimer.invalidate()
}


